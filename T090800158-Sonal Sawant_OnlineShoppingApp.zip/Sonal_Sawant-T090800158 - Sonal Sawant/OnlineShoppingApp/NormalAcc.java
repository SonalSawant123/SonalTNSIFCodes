public abstract class NormalAcc extends ShopAcc {
    private float deliveryCharge;

    public NormalAcc(int accNo, String accNm, float charges, float deliveryCharge) {
        super(accNo, accNm, charges);
        this.deliveryCharge = deliveryCharge;
    }

    public float getDeliveryCharge() {
        return deliveryCharge;
    }

    @Override
    public void bookProduct(float charges) {
        System.out.println("Normal account: Product booked with charges: " + charges + " and delivery charge: " + deliveryCharge);
    }

    @Override
    public String toString() {
        return super.toString() + ", Delivery Charge: " + deliveryCharge;
    }
}
