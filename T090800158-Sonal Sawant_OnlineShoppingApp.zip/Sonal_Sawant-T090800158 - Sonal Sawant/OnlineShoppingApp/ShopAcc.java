public abstract class ShopAcc {
    private int accNo;
    private String accNm;
    private float charges;

    public ShopAcc(int accNo, String accNm, float charges) {
        this.accNo = accNo;
        this.accNm = accNm;
        this.charges = charges;
    }

    public abstract void bookProduct(float charges);

    public void items(float charges) {
        System.out.println("Items booked worth: " + charges);
    }

    @Override
    public String toString() {
        return "Account No: " + accNo + ", Account Name: " + accNm + ", Charges: " + charges;
    }
}
