public class Main {
    public static void main(String[] args) {
        ShopFactory shopFactory = new GSShopFactory();

        // Creating Prime Account
        PrimeAcc primeAcc = shopFactory.getNewPrimeAccount(101, "AAA", 5000, true);
        primeAcc.bookProduct(500);
        System.out.println(primeAcc.toString());

        // Creating Normal Account
        NormalAcc normalAcc = shopFactory.getNewNormalAccount(102, "BBB", 3000, 50);
        normalAcc.bookProduct(300);
        System.out.println(normalAcc.toString());
    }
}
